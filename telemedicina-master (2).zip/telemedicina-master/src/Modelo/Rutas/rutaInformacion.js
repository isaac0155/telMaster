module.exports = {
  get:
  {
    inicio: '/'
  },
  post:
  {

  },
  vista:
  {
    inicio: 'inicio'
  },
  ver:
  {
    inicio: 'nada'
  }
};
