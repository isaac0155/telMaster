
import React, { Component } from "react";

import Boton from './../componentes/boton.js'


class Inicio extends Component
{
  render()
  {
    return (
      <div>
        Inicio
      </div>
    )
  }
}
export default Inicio;
