import React from "react"
import { render } from "react-dom"

import Inicio from "./../paginas/inicio.js"
import 'bootstrap/dist/css/bootstrap.min.css';


render(<Inicio/>, document.getElementById("react"));
